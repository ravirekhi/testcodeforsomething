db_config = {'user': 'root',
             'password': 'ece1779pass',
             #'host': '34.206.92.95',
              'host':"172.31.46.122",
             'database': 'ece1779'}

s3_config = { 'bucket':'ece1779.a1.fk',
              'url' : 'https://s3.amazonaws.com/ece1779.a1.fk'
            }

